---
layout: author
title: Author
permalink: author/michelle/
feature_image: feature-sea
author_avatar: michelle
author_name: Michelle Jones
title: Michelle Jones
fav_posts:
  post_1 : ['12 Reasons to quite your job','ten-reasons-to-travel-the-world/', 'Ask yourself, why not? What is the number one reason you wouldn’t. If the reason you get back is fear, you should just do it.']
  post_2 : ['CSS with Superpowers', 'css-with-superpowers/', 'Sass is completely compatible with all versions of CSS. We take this compatibility seriously, so that you can seamlessly use any available CSS libraries.']
  post_3 : ['Its Not Always That Simple
', 'its-not-always-that-simple/', 'If you always do what you’ve always done, you’ll always get what you’ve always had.']

---

# Michelle Jones

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!