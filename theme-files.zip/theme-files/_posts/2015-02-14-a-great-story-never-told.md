---
layout: post
date: 2015-02-10
categories: storytime life journey
author_name : Michelle Jones
author_url : /author/michelle
author_avatar: michelle
show_avatar : true
read_time : 12
feature_image: feature-wolf
show_related_posts: true
square_related: recommend-woods
---

I've never told this to anyone. Sit yourself down and strap yourself in, you will experience some turbulence before you reach a steady altitude.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam nihil eum cum quas! Consectetur aliquam molestias quos voluptatum recusandae accusantium eaque sed architecto esse. Ut obcaecati, porro numquam sed. Odio.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse quam provident accusamus vero autem culpa illum quo enim maiores eius error, sapiente inventore cum hic earum. Libero porro quisquam harum.

![iceland]({{site.url}}/{{site.baseurl}}img/post-assets/iceland.jpg)


Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam nihil eum cum quas! Consectetur aliquam molestias quos voluptatum recusandae accusantium eaque sed architecto esse. Ut obcaecati, porro numquam sed. Odio.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse quam provident accusamus vero autem culpa illum quo enim maiores eius error, sapiente inventore cum hic earum. Libero porro quisquam harum.


