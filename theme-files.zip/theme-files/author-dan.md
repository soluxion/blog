---
layout: author
title: Author
permalink: author/dan/
feature_image: feature-plantpot
author_avatar: dan
author_name: Dan Robberts
title: Dan Robberts
fav_posts:
  post_1 : ['Supercharge Your Workflow With Grunt', 'supercharge-your-workflow-with-grunt/', 'The Grunt ecosystem is huge and it’s growing every day. With literally hundreds of plugins to choose from, you can use Grunt to automate just about anything with a minimum of effort. ']
  post_2 : ['Why React JS Will Change the World', 'why-react-js-will-change-the-world/', 'React components implement a render() method that takes input data and returns what to display.']

---

# Dan Robberts

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!