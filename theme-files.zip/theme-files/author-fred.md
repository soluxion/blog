---
layout: author
title: Author
permalink: author/fred/
feature_image: feature-wolf
author_avatar: fred
title: Fred Smith
author_name: Fred Smith
fav_posts:
  post_1 : ['You Dont Have To Be Great To Get Started', 'you-dont-have-to-be-great-to-get-started/', 'It was a cold December morning, as I sat out on my porch I decided today was the day.']
  post_2 : ['Stop Thinking And Start Doing', 'stop-thinking-and-start-doing/', 'Get out of your head. Every good decision starts with a momment of action. What are you going to do today!']
  post_3 : ['Fake It Until You Make It', 'fake-it-until-you-make-it/', 'Don’t listen to your critics, most people spend all day talking about what others are doing and no time doing anything themselves.']

---

# Fred Smith

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis necessitatibus repellat et similique, assumenda dolor possimus sunt repellendus ratione quas nihil expedita maiores, ex id odio molestiae ipsam officiis magni!